document.addEventListener("DOMContentLoaded", function() {
    const donationForm = document.getElementById('donation-form');

    donationForm.addEventListener('submit', function(event) {
        event.preventDefault();

        const amount = document.getElementById('amount').value;
        const name = document.getElementById('name').value;
        const email = document.getElementById('email').value;

        // Simulate donation process (replace with actual donation logic)
        alert(`Thank you, ${name}! Your donation of $${amount} has been received. We will send a confirmation email to ${email}.`);
        donationForm.reset();
    });
});
