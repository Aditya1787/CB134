document.addEventListener("DOMContentLoaded", function() {
    const commentForm = document.getElementById('comment-form');
    const commentsContainer = document.getElementById('comments-container');

    commentForm.addEventListener('submit', function(event) {
        event.preventDefault();

        const name = document.getElementById('name').value;
        const comment = document.getElementById('comment').value;

        const commentDiv = document.createElement('div');
        commentDiv.innerHTML = `<strong>${name}:</strong> ${comment}`;
        commentsContainer.appendChild(commentDiv);

        // Clear form fields after submitting comment
        document.getElementById('name').value = '';
        document.getElementById('comment').value = '';
    });
});
